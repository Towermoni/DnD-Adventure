﻿Public Class Armor

    Private armorStats As New List(Of Double)

    Sub New()

        armorStats.Add(0)


    End Sub

    Public Property aStats()
        Get
            Return armorStats
        End Get
        Set(value)
            armorStats = value
        End Set
    End Property
End Class
