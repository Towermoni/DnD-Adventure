﻿Public Class Character

    Private cHealth As Integer
    Private cName As String
    Private cClass As String
    Private cStats As New List(Of Integer)

    Sub New()
        cStats.Add(0)
        cStats.Add(0)
        cStats.Add(0)
        cStats.Add(0)
        cStats.Add(0)
        cStats.Add(0)
        cStats.Add(0)

    End Sub

    Public Property Health() As String
        Get
            Return cHealth
        End Get
        Set(ByVal value As String)
            cHealth = Health
        End Set
    End Property

    Public Property Name() As String
        Get
            Return cName
        End Get
        Set(ByVal value As String)
            cName = value
        End Set
    End Property

    Public Property Role() As String
        Get
            Return cClass
        End Get
        Set(ByVal value As String)
            cClass = value
        End Set
    End Property

    Public Property Stats() As List(Of Integer)
        Get
            Return cStats
        End Get
        Set(ByVal value As List(Of Integer))
            cStats = value
        End Set
    End Property

End Class
