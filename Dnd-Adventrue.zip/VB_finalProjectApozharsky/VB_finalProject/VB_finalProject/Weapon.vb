﻿Public Class Weapon


    Private weaponStats As New List(Of Integer)

    Sub New()
        weaponStats.Add(0)
        weaponStats.Add(0)
    End Sub

    Public Property wStats() As List(Of Integer)
        Get
            Return weaponStats
        End Get
        Set(ByVal value As List(Of Integer))
            weaponStats = value
        End Set
    End Property
End Class
