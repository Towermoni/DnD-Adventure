﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.RTxtBox = New System.Windows.Forms.RichTextBox()
        Me.btnAction = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.lblHealth = New System.Windows.Forms.Label()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.lblSTR = New System.Windows.Forms.Label()
        Me.lblDEX = New System.Windows.Forms.Label()
        Me.lblCHA = New System.Windows.Forms.Label()
        Me.btnClass = New System.Windows.Forms.Button()
        Me.lblExperience = New System.Windows.Forms.Label()
        Me.lblExp = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.lblINT = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.lblWeapon = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.lblDamage = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.lblLevel = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.lblArmor = New System.Windows.Forms.Label()
        Me.lblAN = New System.Windows.Forms.Label()
        Me.lblArmorName = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.lblCrit = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'RTxtBox
        '
        Me.RTxtBox.Location = New System.Drawing.Point(347, 12)
        Me.RTxtBox.Name = "RTxtBox"
        Me.RTxtBox.Size = New System.Drawing.Size(303, 270)
        Me.RTxtBox.TabIndex = 0
        Me.RTxtBox.Text = ""
        '
        'btnAction
        '
        Me.btnAction.Location = New System.Drawing.Point(413, 317)
        Me.btnAction.Name = "btnAction"
        Me.btnAction.Size = New System.Drawing.Size(179, 49)
        Me.btnAction.TabIndex = 1
        Me.btnAction.Text = "Continue"
        Me.btnAction.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(31, 29)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(53, 17)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "Name :"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(31, 75)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(50, 17)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "Class :"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(31, 123)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(35, 17)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "HP :"
        '
        'lblHealth
        '
        Me.lblHealth.AutoSize = True
        Me.lblHealth.Location = New System.Drawing.Point(129, 123)
        Me.lblHealth.Name = "lblHealth"
        Me.lblHealth.Size = New System.Drawing.Size(13, 17)
        Me.lblHealth.TabIndex = 8
        Me.lblHealth.Text = "*"
        '
        'ComboBox1
        '
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Items.AddRange(New Object() {"Paladin", "Rouge", "Barbarian"})
        Me.ComboBox1.Location = New System.Drawing.Point(97, 75)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(121, 24)
        Me.ComboBox1.TabIndex = 9
        Me.ComboBox1.Text = "Paladin"
        '
        'txtName
        '
        Me.txtName.Location = New System.Drawing.Point(97, 29)
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(100, 22)
        Me.txtName.TabIndex = 10
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(31, 163)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(44, 17)
        Me.Label4.TabIndex = 11
        Me.Label4.Text = "STR :"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(31, 192)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(44, 17)
        Me.Label5.TabIndex = 12
        Me.Label5.Text = "DEX :"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(31, 220)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(44, 17)
        Me.Label6.TabIndex = 13
        Me.Label6.Text = "CHA :"
        '
        'lblSTR
        '
        Me.lblSTR.AutoSize = True
        Me.lblSTR.Location = New System.Drawing.Point(129, 163)
        Me.lblSTR.Name = "lblSTR"
        Me.lblSTR.Size = New System.Drawing.Size(13, 17)
        Me.lblSTR.TabIndex = 14
        Me.lblSTR.Text = "*"
        '
        'lblDEX
        '
        Me.lblDEX.AutoSize = True
        Me.lblDEX.Location = New System.Drawing.Point(129, 192)
        Me.lblDEX.Name = "lblDEX"
        Me.lblDEX.Size = New System.Drawing.Size(13, 17)
        Me.lblDEX.TabIndex = 15
        Me.lblDEX.Text = "*"
        '
        'lblCHA
        '
        Me.lblCHA.AutoSize = True
        Me.lblCHA.Location = New System.Drawing.Point(129, 220)
        Me.lblCHA.Name = "lblCHA"
        Me.lblCHA.Size = New System.Drawing.Size(13, 17)
        Me.lblCHA.TabIndex = 16
        Me.lblCHA.Text = "*"
        '
        'btnClass
        '
        Me.btnClass.Location = New System.Drawing.Point(34, 317)
        Me.btnClass.Name = "btnClass"
        Me.btnClass.Size = New System.Drawing.Size(163, 49)
        Me.btnClass.TabIndex = 17
        Me.btnClass.Text = "Generate Class"
        Me.btnClass.UseVisualStyleBackColor = True
        '
        'lblExperience
        '
        Me.lblExperience.AutoSize = True
        Me.lblExperience.Location = New System.Drawing.Point(164, 123)
        Me.lblExperience.Name = "lblExperience"
        Me.lblExperience.Size = New System.Drawing.Size(90, 17)
        Me.lblExperience.TabIndex = 18
        Me.lblExperience.Text = "Experience : "
        '
        'lblExp
        '
        Me.lblExp.AutoSize = True
        Me.lblExp.Location = New System.Drawing.Point(271, 123)
        Me.lblExp.Name = "lblExp"
        Me.lblExp.Size = New System.Drawing.Size(13, 17)
        Me.lblExp.TabIndex = 19
        Me.lblExp.Text = "*"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(37, 247)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(38, 17)
        Me.Label7.TabIndex = 21
        Me.Label7.Text = "INT :"
        '
        'lblINT
        '
        Me.lblINT.AutoSize = True
        Me.lblINT.Location = New System.Drawing.Point(129, 247)
        Me.lblINT.Name = "lblINT"
        Me.lblINT.Size = New System.Drawing.Size(13, 17)
        Me.lblINT.TabIndex = 22
        Me.lblINT.Text = "*"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(691, 33)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(69, 17)
        Me.Label8.TabIndex = 23
        Me.Label8.Text = "Weapon :"
        '
        'lblWeapon
        '
        Me.lblWeapon.AutoSize = True
        Me.lblWeapon.Location = New System.Drawing.Point(787, 33)
        Me.lblWeapon.Name = "lblWeapon"
        Me.lblWeapon.Size = New System.Drawing.Size(13, 17)
        Me.lblWeapon.TabIndex = 24
        Me.lblWeapon.Text = "*"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(691, 82)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(69, 17)
        Me.Label9.TabIndex = 26
        Me.Label9.Text = "Damage :"
        '
        'lblDamage
        '
        Me.lblDamage.AutoSize = True
        Me.lblDamage.Location = New System.Drawing.Point(787, 82)
        Me.lblDamage.Name = "lblDamage"
        Me.lblDamage.Size = New System.Drawing.Size(13, 17)
        Me.lblDamage.TabIndex = 28
        Me.lblDamage.Text = "*"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(195, 163)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(50, 17)
        Me.Label11.TabIndex = 30
        Me.Label11.Text = "Level :"
        '
        'lblLevel
        '
        Me.lblLevel.AutoSize = True
        Me.lblLevel.Location = New System.Drawing.Point(271, 163)
        Me.lblLevel.Name = "lblLevel"
        Me.lblLevel.Size = New System.Drawing.Size(13, 17)
        Me.lblLevel.TabIndex = 31
        Me.lblLevel.Text = "*"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(691, 256)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(69, 17)
        Me.Label12.TabIndex = 32
        Me.Label12.Text = "Defence :"
        '
        'lblArmor
        '
        Me.lblArmor.AutoSize = True
        Me.lblArmor.Location = New System.Drawing.Point(787, 256)
        Me.lblArmor.Name = "lblArmor"
        Me.lblArmor.Size = New System.Drawing.Size(13, 17)
        Me.lblArmor.TabIndex = 33
        Me.lblArmor.Text = "*"
        '
        'lblAN
        '
        Me.lblAN.AutoSize = True
        Me.lblAN.Location = New System.Drawing.Point(706, 220)
        Me.lblAN.Name = "lblAN"
        Me.lblAN.Size = New System.Drawing.Size(54, 17)
        Me.lblAN.TabIndex = 36
        Me.lblAN.Text = "Armor :"
        '
        'lblArmorName
        '
        Me.lblArmorName.AutoSize = True
        Me.lblArmorName.Location = New System.Drawing.Point(787, 220)
        Me.lblArmorName.Name = "lblArmorName"
        Me.lblArmorName.Size = New System.Drawing.Size(13, 17)
        Me.lblArmorName.TabIndex = 37
        Me.lblArmorName.Text = "*"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(723, 136)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(37, 17)
        Me.Label10.TabIndex = 38
        Me.Label10.Text = "Crit :"
        '
        'lblCrit
        '
        Me.lblCrit.AutoSize = True
        Me.lblCrit.Location = New System.Drawing.Point(787, 136)
        Me.lblCrit.Name = "lblCrit"
        Me.lblCrit.Size = New System.Drawing.Size(13, 17)
        Me.lblCrit.TabIndex = 39
        Me.lblCrit.Text = "*"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(935, 392)
        Me.Controls.Add(Me.lblCrit)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.lblArmorName)
        Me.Controls.Add(Me.lblAN)
        Me.Controls.Add(Me.lblArmor)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.lblLevel)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.lblDamage)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.lblWeapon)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.lblINT)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.lblExp)
        Me.Controls.Add(Me.lblExperience)
        Me.Controls.Add(Me.btnClass)
        Me.Controls.Add(Me.lblCHA)
        Me.Controls.Add(Me.lblDEX)
        Me.Controls.Add(Me.lblSTR)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.txtName)
        Me.Controls.Add(Me.ComboBox1)
        Me.Controls.Add(Me.lblHealth)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnAction)
        Me.Controls.Add(Me.RTxtBox)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents RTxtBox As RichTextBox
    Friend WithEvents btnAction As Button
    Friend WithEvents Label1 As Label

    Friend WithEvents Label2 As Label

    Friend WithEvents Label3 As Label
    Friend WithEvents lblHealth As Label
    Friend WithEvents ComboBox1 As ComboBox
    Friend WithEvents txtName As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents lblSTR As Label
    Friend WithEvents lblDEX As Label
    Friend WithEvents lblCHA As Label
    Friend WithEvents btnClass As Button
    Friend WithEvents lblExperience As Label
    Friend WithEvents lblExp As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents lblINT As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents lblWeapon As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents lblDamage As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents lblLevel As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents lblArmor As Label
    Friend WithEvents lblAN As Label
    Friend WithEvents lblArmorName As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents lblCrit As Label
End Class